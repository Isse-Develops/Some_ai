# AI Chatbot (Frontend Demo)

A clean, modern chatbot interface built with pure **HTML, CSS & JavaScript**.  
No frameworks, no build step, **no external AI APIs**.

Perfect as a GitHub project / starting template.

## Features

- New Chat + multiple chat history (sidebar)
- Persistent chats (saved in browser `localStorage`)
- Dark mode / Light mode toggle
- Settings panel
- Simulated “Sign in with Google” (no real OAuth / no API keys needed)
- Responsive design (works on mobile)
- Typing indicator & smooth animations
- Suggestion chips on the welcome screen

## Screenshots

Open `index.html` in your browser to try it.

## How to run

### Option 1 – Fastest
Just open `index.html` in any modern browser.

### Option 2 – Local server (recommended)
```bash
# If you have Python
python -m http.server 8000

# Or with Node
npx serve .
```
Then visit `http://localhost:8000`

## Project structure

```
ai-chatbot/
├── index.html      # Main page
├── styles.css      # All styles + themes
├── script.js       # Chat logic, storage, simulated replies
└── README.md
```

## Important notes

- **No AI API** is used. All replies are generated with simple keyword matching + fallbacks.
- Everything is stored locally in the browser (`localStorage`).
- “Sign in with Google” is **simulated** for demo purposes (no real Google login / no backend).
- You can later replace the `generateResponse()` function with a call to a local LLM (e.g. Ollama) if you want real AI answers while still staying offline.

## Customization ideas

- Connect Ollama / LM Studio for real local AI
- Add more sophisticated response logic
- Export / import chats
- Add markdown rendering for bot messages

## License

MIT – feel free to use and modify.
