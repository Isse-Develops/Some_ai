/**
 * AI Chatbot - Frontend Demo
 * Fully local, no external AI APIs.
 * Data persisted in localStorage.
 */

(function () {
  "use strict";

  // ===== State =====
  let chats = [];
  let currentChatId = null;
  let isLoggedIn = false;
  let userName = "User";
  let isGenerating = false;

  // ===== DOM Elements =====
  const sidebar = document.getElementById("sidebar");
  const chatList = document.getElementById("chatList");
  const chatTitle = document.getElementById("chatTitle");
  const messagesEl = document.getElementById("messages");
  const welcomeScreen = document.getElementById("welcomeScreen");
  const userInput = document.getElementById("userInput");
  const btnSend = document.getElementById("btnSend");
  const btnNewChat = document.getElementById("btnNewChat");
  const btnSettings = document.getElementById("btnSettings");
  const settingsModal = document.getElementById("settingsModal");
  const btnCloseSettings = document.getElementById("btnCloseSettings");
  const btnThemeToggle = document.getElementById("btnThemeToggle");
  const themeLight = document.getElementById("themeLight");
  const themeDark = document.getElementById("themeDark");
  const btnGoogleLogin = document.getElementById("btnGoogleLogin");
  const btnLogout = document.getElementById("btnLogout");
  const loginStatus = document.getElementById("loginStatus");
  const btnOpenSidebar = document.getElementById("btnOpenSidebar");
  const btnCloseSidebar = document.getElementById("btnCloseSidebar");

  // ===== Storage Helpers =====
  function loadState() {
    try {
      const savedChats = localStorage.getItem("chatbot_chats");
      const savedCurrent = localStorage.getItem("chatbot_current");
      const savedTheme = localStorage.getItem("chatbot_theme");
      const savedLogin = localStorage.getItem("chatbot_login");

      chats = savedChats ? JSON.parse(savedChats) : [];
      currentChatId = savedCurrent || null;
      isLoggedIn = savedLogin === "true";

      if (savedTheme === "dark" || savedTheme === "light") {
        setTheme(savedTheme, false);
      } else {
        // Prefer system preference
        const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        setTheme(prefersDark ? "dark" : "light", false);
      }
    } catch (e) {
      console.error("Failed to load state:", e);
      chats = [];
      currentChatId = null;
    }
  }

  function saveChats() {
    try {
      localStorage.setItem("chatbot_chats", JSON.stringify(chats));
      localStorage.setItem("chatbot_current", currentChatId || "");
    } catch (e) {
      console.error("Failed to save chats:", e);
    }
  }

  function saveLogin() {
    localStorage.setItem("chatbot_login", isLoggedIn ? "true" : "false");
  }

  // ===== Theme =====
  function setTheme(theme, save = true) {
    document.documentElement.setAttribute("data-theme", theme);
    themeLight.classList.toggle("active", theme === "light");
    themeDark.classList.toggle("active", theme === "dark");
    if (save) {
      localStorage.setItem("chatbot_theme", theme);
    }
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    setTheme(current === "light" ? "dark" : "light");
  }

  // ===== Chat Management =====
  function generateId() {
    return "chat_" + Date.now() + "_" + Math.random().toString(36).slice(2, 9);
  }

  function createNewChat() {
    const id = generateId();
    const chat = {
      id,
      title: "New Chat",
      messages: [],
      createdAt: Date.now(),
    };
    chats.unshift(chat);
    currentChatId = id;
    saveChats();
    renderChatList();
    renderMessages();
    closeSidebarMobile();
    userInput.focus();
  }

  function getCurrentChat() {
    return chats.find((c) => c.id === currentChatId) || null;
  }

  function switchChat(id) {
    currentChatId = id;
    saveChats();
    renderChatList();
    renderMessages();
    closeSidebarMobile();
  }

  function deleteChat(id, event) {
    event.stopPropagation();
    chats = chats.filter((c) => c.id !== id);
    if (currentChatId === id) {
      currentChatId = chats.length > 0 ? chats[0].id : null;
    }
    saveChats();
    renderChatList();
    renderMessages();
  }

  function updateChatTitle(chat) {
    if (chat.messages.length > 0 && chat.title === "New Chat") {
      const firstUserMsg = chat.messages.find((m) => m.role === "user");
      if (firstUserMsg) {
        chat.title = firstUserMsg.content.slice(0, 40) + (firstUserMsg.content.length > 40 ? "…" : "");
      }
    }
  }

  // ===== Rendering =====
  function renderChatList() {
    chatList.innerHTML = "";
    if (chats.length === 0) {
      const empty = document.createElement("p");
      empty.style.cssText = "padding:12px;font-size:13px;color:var(--text-muted);text-align:center;";
      empty.textContent = "No chats yet";
      chatList.appendChild(empty);
      return;
    }

    chats.forEach((chat) => {
      const item = document.createElement("button");
      item.className = "chat-item" + (chat.id === currentChatId ? " active" : "");
      item.innerHTML = `
        <span class="chat-item-title">${escapeHtml(chat.title)}</span>
        <span class="chat-item-delete" title="Delete chat">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </span>
      `;
      item.addEventListener("click", () => switchChat(chat.id));
      item.querySelector(".chat-item-delete").addEventListener("click", (e) => deleteChat(chat.id, e));
      chatList.appendChild(item);
    });
  }

  function renderMessages() {
    const chat = getCurrentChat();
    messagesEl.innerHTML = "";

    if (!chat || chat.messages.length === 0) {
      welcomeScreen.classList.remove("hidden");
      messagesEl.classList.add("hidden");
      chatTitle.textContent = "New Chat";
      return;
    }

    welcomeScreen.classList.add("hidden");
    messagesEl.classList.remove("hidden");
    chatTitle.textContent = chat.title;

    chat.messages.forEach((msg) => {
      const div = document.createElement("div");
      div.className = "message " + msg.role;
      const avatarText = msg.role === "user" ? (isLoggedIn ? userName.charAt(0).toUpperCase() : "U") : "AI";
      div.innerHTML = `
        <div class="message-avatar">${avatarText}</div>
        <div class="message-content">${escapeHtml(msg.content)}</div>
      `;
      messagesEl.appendChild(div);
    });

    // Scroll to bottom
    const container = document.getElementById("chatContainer");
    container.scrollTop = container.scrollHeight;
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // ===== Simulated AI Responses (No API) =====
  function generateResponse(userMessage) {
    const lower = userMessage.toLowerCase().trim();

    // Simple keyword-based responses
    if (lower.match(/^(hi|hello|hey|hola|yo)\b/)) {
      return "Hello! I'm a local demo chatbot. How can I help you today?";
    }
    if (lower.includes("how are you")) {
      return "I'm doing well, thank you for asking! I'm a frontend-only demo, so I run entirely in your browser.";
    }
    if (lower.includes("your name") || lower.includes("who are you")) {
      return "I'm a simple demo chatbot built with HTML, CSS and JavaScript. No external AI API is used — all responses are generated locally.";
    }
    if (lower.includes("quantum")) {
      return "Quantum computing uses quantum bits (qubits) that can be in multiple states at once (superposition). This allows certain calculations to be performed much faster than classical computers for specific problems like cryptography and simulation.";
    }
    if (lower.includes("email") || lower.includes("write")) {
      return "Sure! Here's a simple professional email template:\n\nSubject: [Your Subject]\n\nDear [Name],\n\nI hope this message finds you well. [Your main point here].\n\nPlease let me know if you have any questions.\n\nBest regards,\n[Your Name]";
    }
    if (lower.includes("productivity") || lower.includes("habit")) {
      return "Good productivity habits:\n• Start with the most important task (Eat the Frog)\n• Use time blocking\n• Take short breaks (Pomodoro)\n• Limit distractions\n• Review your day in the evening\n• Sleep well and move your body";
    }
    if (lower.includes("project") || lower.includes("idea")) {
      return "Here are a few weekend project ideas:\n• Build a personal portfolio site\n• Create a simple todo app with localStorage\n• Learn a new CSS animation technique\n• Contribute to an open-source project on GitHub\n• Write a small Python script that automates something you do often";
    }
    if (lower.includes("help") || lower.includes("what can you do")) {
      return "I can chat with you, answer simple questions, give writing help, and share ideas. Because this is a no-API demo, my knowledge is limited to pre-written responses. You can later connect a local LLM (like Ollama) for real AI power.";
    }
    if (lower.includes("thank")) {
      return "You're welcome! Feel free to ask me anything else.";
    }
    if (lower.includes("joke")) {
      return "Why do programmers prefer dark mode?\n\nBecause light attracts bugs! 🐛";
    }
    if (lower.includes("time") || lower.includes("date")) {
      return "The current date and time on your device is:\n" + new Date().toLocaleString();
    }

    // Default fallback
    const fallbacks = [
      "That's an interesting question! In a full version with a local LLM this would get a much smarter answer. For now I'm a simple demo.",
      "I understand. Since I'm running without any AI API, I can only give basic replies. Try asking about productivity, writing emails, or project ideas!",
      "Thanks for your message. This chatbot stores everything locally in your browser and never calls external services for answers.",
      "Got it! Remember you can create new chats from the sidebar and switch between them anytime.",
    ];
    return fallbacks[Math.floor(Math.random() * fallbacks.length)];
  }

  // ===== Send Message =====
  async function sendMessage(text) {
    const content = (text || userInput.value).trim();
    if (!content || isGenerating) return;

    // Ensure we have a chat
    if (!currentChatId) {
      createNewChat();
    }

    const chat = getCurrentChat();
    if (!chat) return;

    // Add user message
    chat.messages.push({ role: "user", content });
    updateChatTitle(chat);
    saveChats();
    renderChatList();
    renderMessages();

    userInput.value = "";
    autoResize();
    updateSendButton();
    isGenerating = true;
    btnSend.disabled = true;

    // Show typing indicator
    const typingDiv = document.createElement("div");
    typingDiv.className = "message bot";
    typingDiv.id = "typingIndicator";
    typingDiv.innerHTML = `
      <div class="message-avatar">AI</div>
      <div class="message-content">
        <div class="typing"><span></span><span></span><span></span></div>
      </div>
    `;
    messagesEl.appendChild(typingDiv);
    const container = document.getElementById("chatContainer");
    container.scrollTop = container.scrollHeight;

    // Simulate thinking delay
    await new Promise((r) => setTimeout(r, 600 + Math.random() * 800));

    // Remove typing and add response
    const typingEl = document.getElementById("typingIndicator");
    if (typingEl) typingEl.remove();

    const reply = generateResponse(content);
    chat.messages.push({ role: "bot", content: reply });
    saveChats();
    renderMessages();

    isGenerating = false;
    updateSendButton();
    userInput.focus();
  }

  // ===== Input Helpers =====
  function autoResize() {
    userInput.style.height = "auto";
    userInput.style.height = Math.min(userInput.scrollHeight, 160) + "px";
  }

  function updateSendButton() {
    btnSend.disabled = !userInput.value.trim() || isGenerating;
  }

  // ===== Login (Simulated) =====
  function handleLogin() {
    // Simulated Google login – no real OAuth / API
    isLoggedIn = true;
    userName = "Demo User";
    saveLogin();
    updateLoginUI();
    renderMessages(); // refresh avatars
  }

  function handleLogout() {
    isLoggedIn = false;
    userName = "User";
    saveLogin();
    updateLoginUI();
    renderMessages();
  }

  function updateLoginUI() {
    if (isLoggedIn) {
      loginStatus.textContent = "Signed in as " + userName;
      btnGoogleLogin.classList.add("hidden");
      btnLogout.classList.remove("hidden");
    } else {
      loginStatus.textContent = "Not signed in";
      btnGoogleLogin.classList.remove("hidden");
      btnLogout.classList.add("hidden");
    }
  }

  // ===== Mobile Sidebar =====
  function openSidebarMobile() {
    sidebar.classList.add("open");
    let backdrop = document.querySelector(".sidebar-backdrop");
    if (!backdrop) {
      backdrop = document.createElement("div");
      backdrop.className = "sidebar-backdrop";
      backdrop.addEventListener("click", closeSidebarMobile);
      document.body.appendChild(backdrop);
    }
    backdrop.classList.add("show");
  }

  function closeSidebarMobile() {
    sidebar.classList.remove("open");
    const backdrop = document.querySelector(".sidebar-backdrop");
    if (backdrop) backdrop.classList.remove("show");
  }

  // ===== Event Listeners =====
  btnNewChat.addEventListener("click", createNewChat);
  btnSend.addEventListener("click", () => sendMessage());
  btnSettings.addEventListener("click", () => {
    settingsModal.classList.add("open");
    closeSidebarMobile();
  });
  btnCloseSettings.addEventListener("click", () => settingsModal.classList.remove("open"));
  settingsModal.addEventListener("click", (e) => {
    if (e.target === settingsModal) settingsModal.classList.remove("open");
  });

  btnThemeToggle.addEventListener("click", toggleTheme);
  themeLight.addEventListener("click", () => setTheme("light"));
  themeDark.addEventListener("click", () => setTheme("dark"));

  btnGoogleLogin.addEventListener("click", handleLogin);
  btnLogout.addEventListener("click", handleLogout);

  btnOpenSidebar.addEventListener("click", openSidebarMobile);
  btnCloseSidebar.addEventListener("click", closeSidebarMobile);

  userInput.addEventListener("input", () => {
    autoResize();
    updateSendButton();
  });

  userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Suggestion chips
  document.querySelectorAll(".suggestion").forEach((btn) => {
    btn.addEventListener("click", () => {
      const prompt = btn.getAttribute("data-prompt");
      sendMessage(prompt);
    });
  });

  // ===== Init =====
  loadState();
  renderChatList();
  renderMessages();
  updateLoginUI();
  updateSendButton();

  // If no chats exist, create one ready to go
  if (chats.length === 0) {
    // Don't auto-create – let welcome screen show
  } else if (!currentChatId || !getCurrentChat()) {
    currentChatId = chats[0].id;
    saveChats();
    renderChatList();
    renderMessages();
  }
})();
